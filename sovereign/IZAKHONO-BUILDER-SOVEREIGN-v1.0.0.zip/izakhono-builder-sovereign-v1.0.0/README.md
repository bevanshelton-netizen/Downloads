# IZAKHONO BUILDER — Sovereign v1.0.0

An owner-controlled, local-first application factory.

## Sovereign core

The builder itself does **not** require Cloudflare, Vercel, Supabase, GitHub, a VPS, a paid database or a paid storage service.

Core operation uses:
- Node.js runtime
- local files
- local project workspace
- local project registry
- local preview server
- local export/package workflow

GitHub can still be used as optional backup/source control. Cloud services can be added later as deployment targets, but they are not the foundation.

## Windows

1. Extract the folder.
2. Double-click `START-IZAKHONO-BUILDER.cmd`.
3. Your browser opens at `http://127.0.0.1:4788`.
4. Create a project, select modules, click **Generate**, **Preview**, or **Package**.

Node.js 22+ is required. No npm install is required because this release uses Node built-in modules only.

## Generated apps

Every generated app gets its own folder under `workspace/` and includes:
- local Node server
- responsive public site
- local JSON data store
- selected-module manifest
- generic local record APIs for selected modules
- Windows launcher
- Unix launcher
- no mandatory external SaaS dependency

## Current modules

CRM, Auth, File Storage, Payments (ledger scaffold only), Email/Notifications (outbox scaffold only), Admin, Analytics, Marketplace, Learning, Video, and provider-neutral AI adapter scaffolding.

## Commercial truth

The Payments module is a ledger/integration scaffold, not a payment processor. AI is an adapter boundary, not a bundled foundation model. Email is an outbox scaffold, not an email delivery network.

## Next sovereign layers

1. IZAKHONO SOURCE — owner-controlled Git/versioning.
2. IZAKHONO RUN — owner-controlled app runtime/process manager.
3. IZAKHONO DATA — PostgreSQL/object storage on our own machines.
4. IZAKHONO EDGE — reverse proxy, TLS, routing and caching.
5. IZAKHONO DEPLOY — publish from Builder to our own nodes.

These can be attached later without replacing the Builder core.
