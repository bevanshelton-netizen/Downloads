import http from "node:http";
import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);
const __filename = fileURLToPath(import.meta.url);
const ROOT = path.dirname(__filename);
const PUBLIC = path.join(ROOT, "public");
const DATA_DIR = path.join(ROOT, "data");
const WORKSPACE = path.join(ROOT, "workspace");
const EXPORTS = path.join(ROOT, "exports");
const DB_FILE = path.join(DATA_DIR, "builder.json");
const HOST = process.env.IZAKHONO_HOST || "127.0.0.1";
const PORT = Number(process.env.IZAKHONO_PORT || 4788);

const MODULES = [
  {id:"crm",name:"Leads & CRM",description:"Local lead capture, enquiries and pipeline records."},
  {id:"auth",name:"Accounts & Auth",description:"User/account scaffolding with local session-ready storage."},
  {id:"files",name:"File Storage",description:"Owner-controlled file area inside the generated app."},
  {id:"payments",name:"Payments",description:"Payment-intent ledger scaffold only; providers plug in later."},
  {id:"email",name:"Email & Notifications",description:"Outbox queue scaffold; provider remains optional."},
  {id:"admin",name:"Admin Dashboard",description:"Private admin surface scaffold."},
  {id:"analytics",name:"Analytics",description:"First-party event log and counters."},
  {id:"marketplace",name:"Marketplace",description:"Listings, jobs/orders and provider/customer records."},
  {id:"learning",name:"Learning",description:"Courses, lessons, assessments and progress records."},
  {id:"video",name:"Video",description:"Video metadata/catalogue scaffold with local media directory."},
  {id:"ai",name:"AI Assistant",description:"Provider-neutral AI adapter boundary; no paid AI dependency baked in."}
];

async function ensureDirs(){
  for (const p of [DATA_DIR, WORKSPACE, EXPORTS]) await fsp.mkdir(p,{recursive:true});
  try { await fsp.access(DB_FILE); } catch { await writeDb({version:1,projects:[]}); }
}
async function readDb(){
  await ensureDirs();
  try { return JSON.parse(await fsp.readFile(DB_FILE,"utf8")); }
  catch { return {version:1,projects:[]}; }
}
async function writeDb(db){
  await fsp.mkdir(DATA_DIR,{recursive:true});
  const tmp = DB_FILE + ".tmp";
  await fsp.writeFile(tmp, JSON.stringify(db,null,2));
  await fsp.rename(tmp, DB_FILE);
}
function slugify(value){
  return String(value||"").toLowerCase().trim()
    .replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").slice(0,60);
}
function send(res,status,body,headers={}){
  const payload = Buffer.isBuffer(body) ? body : Buffer.from(String(body));
  res.writeHead(status,{"content-length":payload.length,...headers});
  res.end(payload);
}
function jsonOut(res,status,obj){ send(res,status,JSON.stringify(obj),{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}); }
function bad(res,message,status=400){ jsonOut(res,status,{ok:false,error:message}); }
async function parseJson(req,limit=512_000){
  let size=0, chunks=[];
  for await (const chunk of req){ size+=chunk.length; if(size>limit) throw new Error("Request too large"); chunks.push(chunk); }
  if(!chunks.length) return {};
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}
function mime(p){
  const ext=path.extname(p).toLowerCase();
  return ({".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8",
    ".json":"application/json; charset=utf-8",".svg":"image/svg+xml",".png":"image/png",".ico":"image/x-icon",
    ".zip":"application/zip",".txt":"text/plain; charset=utf-8",".md":"text/markdown; charset=utf-8"}[ext]||"application/octet-stream");
}
function safeJoin(base, rel){
  const target = path.resolve(base, rel.replace(/^[/\\]+/,""));
  if(!target.startsWith(path.resolve(base)+path.sep) && target!==path.resolve(base)) throw new Error("Unsafe path");
  return target;
}
async function serveFile(res,base,rel){
  let p;
  try { p=safeJoin(base,rel); } catch { return bad(res,"Invalid path",400); }
  try {
    const st=await fsp.stat(p);
    if(st.isDirectory()) p=path.join(p,"index.html");
    const b=await fsp.readFile(p);
    send(res,200,b,{"content-type":mime(p),"cache-control":"no-store"});
  } catch { send(res,404,"Not found",{"content-type":"text/plain; charset=utf-8"}); }
}
function projectById(db,id){ return db.projects.find(p=>p.id===id || p.slug===id); }

function generatedServerSource(appName, modules){
  return `import http from "node:http";
import fsp from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
const __filename=fileURLToPath(import.meta.url), ROOT=path.dirname(__filename);
const PORT=Number(process.env.PORT||3000), HOST=process.env.HOST||"127.0.0.1";
const MODULES=${JSON.stringify(modules)};
const STORE=path.join(ROOT,"data","store.json");
async function load(){try{return JSON.parse(await fsp.readFile(STORE,"utf8"))}catch{return {collections:{},events:[]}}}
async function save(x){await fsp.mkdir(path.dirname(STORE),{recursive:true});await fsp.writeFile(STORE,JSON.stringify(x,null,2))}
function out(res,s,o){const b=Buffer.from(JSON.stringify(o));res.writeHead(s,{"content-type":"application/json","content-length":b.length});res.end(b)}
async function body(req){let x=[];for await(const c of req)x.push(c);return x.length?JSON.parse(Buffer.concat(x).toString("utf8")):{}}
const server=http.createServer(async(req,res)=>{const u=new URL(req.url,"http://local");
 if(u.pathname==="/api/health") return out(res,200,{ok:true,app:${JSON.stringify(appName)},local_first:true,modules:MODULES});
 if(u.pathname==="/api/config") return out(res,200,{name:${JSON.stringify(appName)},modules:MODULES,storage:"local"});
 if(u.pathname.startsWith("/api/records/")){
   const collection=u.pathname.split("/").pop();
   if(!MODULES.includes(collection) && collection!=="general") return out(res,404,{error:"Module not enabled"});
   const db=await load(); db.collections[collection] ||= [];
   if(req.method==="GET") return out(res,200,{items:db.collections[collection]});
   if(req.method==="POST"){const x=await body(req);const item={id:crypto.randomUUID(),...x,created_at:new Date().toISOString()};db.collections[collection].push(item);await save(db);return out(res,201,{item});}
 }
 let rel=u.pathname==="/"?"index.html":u.pathname.slice(1);let p=path.join(ROOT,"public",rel);
 try{const b=await fsp.readFile(p);res.writeHead(200,{"content-type":p.endsWith(".html")?"text/html; charset=utf-8":"application/octet-stream"});res.end(b)}
 catch{res.writeHead(404);res.end("Not found")}
});
server.listen(PORT,HOST,()=>console.log(\`${appName} running at http://\${HOST}:\${PORT}\`));`;
}

function generatedIndex(appName, description, modules){
  const chips = modules.map(m=>`<span>${m}</span>`).join("");
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${appName}</title>
<style>*{box-sizing:border-box}body{margin:0;font-family:Inter,system-ui;background:#07111d;color:#fff}.w{max-width:1080px;margin:auto;padding:9vw 6vw}.tag{color:#73f5c5;font-weight:900;letter-spacing:.12em}.card{margin-top:28px;padding:26px;border:1px solid #25394c;border-radius:20px;background:#0d1926}h1{font-size:clamp(44px,8vw,86px);line-height:.95;margin:14px 0}.muted{color:#9fb2c2;line-height:1.6}.chips{display:flex;gap:8px;flex-wrap:wrap}.chips span{padding:8px 11px;border:1px solid #29445a;border-radius:99px;color:#b9cad6;font-size:12px}.ok{color:#73f5c5}</style></head><body><main class="w"><div class="tag">BUILT WITH IZAKHONO BUILDER</div><h1>${appName}</h1><p class="muted">${description||"Owner-controlled local-first application."}</p><div class="card"><b class="ok">Local-first foundation ready</b><p class="muted">This application runs without Cloudflare, Vercel, Supabase or GitHub. Add product-specific workflows on top of this owner-controlled base.</p><div class="chips">${chips||"<span>core</span>"}</div></div></main></body></html>`;
}

async function generateProject(project){
  const dir=safeJoin(WORKSPACE,project.slug);
  await fsp.mkdir(path.join(dir,"public"),{recursive:true});
  await fsp.mkdir(path.join(dir,"data"),{recursive:true});
  await fsp.mkdir(path.join(dir,"storage"),{recursive:true});
  const packageJson={name:project.slug,version:"0.1.0",private:true,type:"module",scripts:{start:"node server.mjs",dev:"node server.mjs"}};
  const manifest={id:project.id,name:project.name,slug:project.slug,description:project.description,modules:project.modules,created_at:project.created_at,generator:"IZAKHONO BUILDER Sovereign"};
  await fsp.writeFile(path.join(dir,"package.json"),JSON.stringify(packageJson,null,2));
  await fsp.writeFile(path.join(dir,"izakhono.manifest.json"),JSON.stringify(manifest,null,2));
  await fsp.writeFile(path.join(dir,"server.mjs"),generatedServerSource(project.name,project.modules));
  await fsp.writeFile(path.join(dir,"public","index.html"),generatedIndex(project.name,project.description,project.modules));
  await fsp.writeFile(path.join(dir,"data","store.json"),JSON.stringify({collections:{},events:[]},null,2));
  await fsp.writeFile(path.join(dir,"START.cmd"),`@echo off\r\ncd /d "%~dp0"\r\nnode server.mjs\r\npause\r\n`);
  await fsp.writeFile(path.join(dir,"start.sh"),`#!/usr/bin/env bash\ncd "$(dirname "$0")"\nnode server.mjs\n`);
  await fsp.writeFile(path.join(dir,"README.md"),`# ${project.name}\n\nGenerated by IZAKHONO BUILDER Sovereign.\n\n## Run\n\nWindows: double-click \`START.cmd\`\n\nOther systems: \`node server.mjs\`\n\nThis build is local-first. Product-specific modules can be expanded without changing the sovereign foundation.\n`);
  return dir;
}
async function exportProject(project){
  const dir=await generateProject(project);
  const zip=path.join(EXPORTS,`${project.slug}-${Date.now()}.zip`);
  if(process.platform==="win32"){
    const ps=`Compress-Archive -Path '${dir.replaceAll("'","''")}\\*' -DestinationPath '${zip.replaceAll("'","''")}' -Force`;
    await execFileAsync("powershell.exe",["-NoProfile","-Command",ps]);
  } else {
    try { await execFileAsync("zip",["-qr",zip,"."],{cwd:dir}); }
    catch {
      const tgz=zip.replace(/\.zip$/,".tar.gz");
      await execFileAsync("tar",["-czf",tgz,"."],{cwd:dir});
      return tgz;
    }
  }
  return zip;
}

async function route(req,res){
  const u=new URL(req.url,`http://${req.headers.host||"localhost"}`);
  if(u.pathname==="/api/health") return jsonOut(res,200,{ok:true,name:"IZAKHONO BUILDER Sovereign",version:"1.0.0",local_first:true,host:HOST,port:PORT});
  if(u.pathname==="/api/modules") return jsonOut(res,200,{modules:MODULES});
  if(u.pathname==="/api/projects" && req.method==="GET"){
    const db=await readDb(); return jsonOut(res,200,{projects:db.projects});
  }
  if(u.pathname==="/api/projects" && req.method==="POST"){
    let b; try{b=await parseJson(req)}catch(e){return bad(res,e.message)}
    const name=String(b.name||"").trim(), slug=slugify(b.slug||name);
    if(!name || !slug) return bad(res,"Project name is required");
    const allowed=new Set(MODULES.map(m=>m.id));
    const modules=[...new Set(Array.isArray(b.modules)?b.modules.filter(x=>allowed.has(x)):[])];
    const db=await readDb();
    if(db.projects.some(p=>p.slug===slug)) return bad(res,"A project with that slug already exists",409);
    const project={id:crypto.randomUUID(),name,slug,description:String(b.description||"").slice(0,500),modules,status:"draft",created_at:new Date().toISOString(),updated_at:new Date().toISOString()};
    db.projects.unshift(project); await writeDb(db);
    return jsonOut(res,201,{ok:true,project});
  }
  const m=u.pathname.match(/^\/api\/projects\/([^/]+)(?:\/(generate|export|status))?$/);
  if(m){
    const db=await readDb(), project=projectById(db,decodeURIComponent(m[1]));
    if(!project) return bad(res,"Project not found",404);
    if(!m[2] && req.method==="GET") return jsonOut(res,200,{project});
    if(m[2]==="generate" && req.method==="POST"){
      await generateProject(project); project.status="generated";project.updated_at=new Date().toISOString();await writeDb(db);
      return jsonOut(res,200,{ok:true,project,preview:`/preview/${project.slug}/`});
    }
    if(m[2]==="export" && req.method==="POST"){
      try{const file=await exportProject(project);project.status="packaged";project.updated_at=new Date().toISOString();await writeDb(db);
        return jsonOut(res,200,{ok:true,project,download:`/downloads/${path.basename(file)}`});}
      catch(e){return bad(res,`Packaging failed: ${e.message}`,500)}
    }
    if(m[2]==="status" && req.method==="POST"){
      let b;try{b=await parseJson(req)}catch(e){return bad(res,e.message)}
      const allowed=["draft","generated","validated","packaged","deployed","archived"];
      if(!allowed.includes(b.status))return bad(res,"Invalid status");
      project.status=b.status;project.updated_at=new Date().toISOString();await writeDb(db);return jsonOut(res,200,{ok:true,project});
    }
  }
  const preview=u.pathname.match(/^\/preview\/([^/]+)\/?(.*)$/);
  if(preview){
    const slug=slugify(decodeURIComponent(preview[1])); const rel=preview[2]||"index.html";
    return serveFile(res,path.join(WORKSPACE,slug,"public"),rel);
  }
  if(u.pathname.startsWith("/downloads/")) return serveFile(res,EXPORTS,u.pathname.slice("/downloads/".length));
  return serveFile(res,PUBLIC,u.pathname==="/"?"index.html":u.pathname.slice(1));
}

await ensureDirs();
const server=http.createServer((req,res)=>route(req,res).catch(e=>{console.error(e);bad(res,"Internal error",500)}));
server.listen(PORT,HOST,()=>console.log(`IZAKHONO BUILDER Sovereign running at http://${HOST}:${PORT}`));
