@echo off
title IZAKHONO BUILDER
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js 22 or newer is required to run IZAKHONO BUILDER.
  echo Install Node.js once, then run this file again.
  echo.
  pause
  exit /b 1
)
start "" http://127.0.0.1:4788
node server.mjs
pause
