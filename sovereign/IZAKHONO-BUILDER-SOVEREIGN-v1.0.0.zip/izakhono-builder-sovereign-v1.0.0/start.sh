#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js 22+ is required."; exit 1; }
( sleep 1; command -v xdg-open >/dev/null && xdg-open http://127.0.0.1:4788 >/dev/null 2>&1 || true ) &
node server.mjs
