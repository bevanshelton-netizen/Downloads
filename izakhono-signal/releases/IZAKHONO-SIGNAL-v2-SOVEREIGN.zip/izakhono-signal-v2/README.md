# IZAKHONO SIGNAL v2

Owner-controlled marketing data, social publishing and campaign operations platform.

## What v2 adds
- encrypted server-side connector credentials (AES-256-GCM);
- approval-first publishing queue;
- scheduled worker endpoint;
- connector adapter architecture;
- live adapters for Facebook Pages, Instagram publishing, LinkedIn Posts, TikTok direct photo/video init, X v2 posts and generic webhooks;
- normalized campaign metrics ingestion;
- cross-channel analytics summary and CSV/JSON export;
- complete audit log;
- sovereign Docker/IZAKHONO deployment contract;
- no secrets in browser code.

## Safety / platform rules
External networks still require their own developer apps, OAuth approval and scopes. SIGNAL fails closed when a connector is not configured or an action is not supported. TikTok public Direct Post requires TikTok app review; unaudited clients may be restricted by TikTok. LinkedIn requires current versioned API headers and appropriate social permissions. Meta publishing requires valid Page/Instagram professional-account permissions.

## Run locally
1. Copy `.env.example` to `.env` and provide strong `SIGNAL_MASTER_KEY` (64 hex chars) and `SIGNAL_ADMIN_KEY`.
2. Start with `npm start`.
3. Open `http://127.0.0.1:8080`.

The first persistence layer is an encrypted, owner-hosted persistent volume so v2 can run immediately on the sovereign node with no external database dependency. A PostgreSQL storage adapter is the next scale step.
