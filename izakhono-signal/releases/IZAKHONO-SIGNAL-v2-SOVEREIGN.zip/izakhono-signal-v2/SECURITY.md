# Security model

- Provider access tokens are encrypted at rest with AES-256-GCM using `SIGNAL_MASTER_KEY`.
- The browser never receives stored provider tokens.
- Every write action requires `SIGNAL_ADMIN_KEY`.
- Posts must be approved before the worker can publish them.
- All owner mutations create audit entries.
- Network adapters fail closed on missing scopes, tokens, account IDs or version headers.
- Keep the data volume and master key backed up separately; losing the key makes encrypted connector credentials unrecoverable.
