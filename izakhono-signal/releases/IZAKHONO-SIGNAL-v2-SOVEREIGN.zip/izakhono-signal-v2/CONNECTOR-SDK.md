# SIGNAL Connector SDK

Each connector declares `id`, read/write capabilities and a `publish(connection, post)` implementation. Connector secrets are supplied only after server-side decryption.

Normalized post shape:
```json
{
  "text": "Post copy",
  "link_url": "https://example.com",
  "media_url": "https://public.example.com/image.jpg",
  "media_type": "image",
  "privacy_level": "PUBLIC_TO_EVERYONE"
}
```

Normalized metric shape:
```json
{
  "platform": "meta",
  "account_id": "...",
  "campaign_id": "...",
  "date": "2026-09-21",
  "impressions": 1000,
  "clicks": 50,
  "spend": 120.50,
  "conversions": 4,
  "revenue": 799.00
}
```

Add future connectors inside `connectors` in `server.mjs`, or split them into modules once the catalog grows.
